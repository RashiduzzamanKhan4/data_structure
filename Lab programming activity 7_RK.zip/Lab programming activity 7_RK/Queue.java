
public interface  Queue<E> extends Iterable<E>,Cloneable {

    public void enqueue(E item);    
    public E dequeue();    
    public int size( );
    public boolean empty( );
      
}
