import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayQueue<E> implements Queue<E> {
   private E[] data = (E[])(new Object[64]);
   private int front = 0;
   private int rear = 63;
   private int count = 0;

   private int next_index(int i) {
      return (i + 1) % data.length;
   }

   private void ensureCapacity(int minimumCapacity) {
      if (data.length < minimumCapacity) {
         E[] bigger = (E[])(new Object[minimumCapacity]);
         for (int i = 0; i < count; i++) {
            bigger[i] = data[front];
            front = next_index(front);
         }
         front = 0;
         rear = count - 1;
         data = bigger;
      }
   }

   public ArrayQueue() {}

   public void enqueue(E item) {
      if (count == data.length)
         ensureCapacity(2 * count + 1);
      rear = next_index(rear);
      data[rear] = item;
      count++;
   }

   public E dequeue() {
      if (empty())
         throw new NoSuchElementException("Queue is empty!");
      E answer = data[front];
      data[front] = null;
      front = next_index(front);
      count--;
      return answer;
   }

   public int size() {
      return count;
   }

   public boolean empty() {
      return count == 0;
   }

   //implemented equals() method
   @Override
   public boolean equals(Object obj) {
      if (this == obj)
         return true;
      if (!(obj instanceof ArrayQueue))
         return false;

      ArrayQueue<?> other = (ArrayQueue<?>) obj;
      if (this.count != other.count)
         return false;

      int thisIndex = this.front;
      int otherIndex = other.front;

      for (int i = 0; i < count; i++) {
         E thisItem = data[thisIndex];
         Object otherItem = other.data[otherIndex];
         if (!thisItem.equals(otherItem))
            return false;
         thisIndex = next_index(thisIndex);
         otherIndex = other.next_index(otherIndex);
      }
      return true;
   }

   // implemented iterator() method
   @Override
   public Iterator<E> iterator() {
      return new Iterator<E>() {
         private int index = front;
         private int itemsLeft = count;

         public boolean hasNext() {
            return itemsLeft > 0;
         }

         public E next() {
            if (!hasNext())
               throw new NoSuchElementException();
            E value = data[index];
            index = next_index(index);
            itemsLeft--;
            return value;
         }
      };
   }
}
