public class ExQueue {
   public static void main(String[] args) {
      Queue<String> q1 = new ArrayQueue<>();
      Queue<String> q2 = new ArrayQueue<>();

      q1.enqueue("peter");
      q1.enqueue("john");
      q1.enqueue("mary");

      q2.enqueue("peter");
      q2.enqueue("john");
      q2.enqueue("mary");

      System.out.println("Queues equal? " + q1.equals(q2));

      System.out.println("Iterating through q1:");
      for (String name : q1) {
         System.out.println(name);
      }

      q2.dequeue();
      System.out.println("After removing one element, equal? " + q1.equals(q2));
   }
}
